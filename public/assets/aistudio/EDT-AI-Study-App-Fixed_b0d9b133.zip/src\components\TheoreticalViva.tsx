import React, { useState } from 'react';
import {
  HelpCircle,
  Send,
  Award,
  AlertTriangle,
  Sparkles,
  RefreshCw,
  Upload,
  Image as ImageIcon,
  Mic,
  FileText,
  MessageSquare,
  CheckCircle2,
  BookOpen,
  Key,
} from 'lucide-react';
import { CHAPTERS_DATA } from '../data/curriculumData';
import { InteractiveCanvas } from './InteractiveCanvas';
import { MathFormula, MathText } from './MathFormula';
import { aiFetch } from '../utils/apiHelper';

interface TheoreticalVivaProps {
  onAddExp: (amount: number) => void;
  onRecordMistake: (mistake: any) => void;
}

export const TheoreticalViva: React.FC<TheoreticalVivaProps> = ({ onAddExp, onRecordMistake }) => {
  // Mode: 'examiner_mode' (AI asks student) vs 'student_mode' (Student asks AI with any multimodal input)
  const [vivaMode, setVivaMode] = useState<'examiner_mode' | 'student_mode'>('examiner_mode');

  const [selectedChapterId, setSelectedChapterId] = useState<number | 'all'>('all');
  const [isLoading, setIsLoading] = useState(false);

  // Examiner Mode State
  const [session, setSession] = useState<any>(null);
  const [studentAnswerText, setStudentAnswerText] = useState('');

  // Student Asking Mode State (Multimodal)
  const [studentQuestionText, setStudentQuestionText] = useState('');
  const [attachedImageBase64, setAttachedImageBase64] = useState<string | null>(null);
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [useCanvasDrawing, setUseCanvasDrawing] = useState(false);
  const [isVoiceRecording, setIsVoiceRecording] = useState(false);

  // Conversation history in Student Asking Mode
  const [studentQnAHistory, setStudentQnAHistory] = useState<
    Array<{
      question: string;
      image?: string;
      fileName?: string;
      answer: {
        teacherExplanation: string;
        keyTakeaways?: string[];
        followUpCheckQuestion?: string;
        suggestedFormulas?: string[];
      };
    }>
  >([]);

  const currentChapterTitle =
    selectedChapterId === 'all'
      ? 'Xác Suất Thống Kê Toàn Diện'
      : CHAPTERS_DATA.find((c) => c.id === selectedChapterId)?.title || 'XSTK';

  // --- EXAMINER MODE HANDLERS ---
  const handleStartExaminerSession = async () => {
    setIsLoading(true);
    setSession(null);
    setStudentAnswerText('');

    try {
      const response = await aiFetch('/api/tutor/viva', {
        method: 'POST',
        body: JSON.stringify({
          chapterTitle: currentChapterTitle,
          mode: 'examiner_ask',
          history: [],
        }),
      });

      const data = await response.json();
      if (data.success && data.data) {
        setSession({
          chapterTitle: currentChapterTitle,
          history: [],
          currentQuestion: data.data.nextQuestion || 'Em hãy giải thích ý nghĩa của Định lý Giới hạn Trung tâm và khi nào áp dụng?',
          totalScore: 0,
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitAnswerToExaminer = async (canvasDataUrl?: string, canvasText?: string) => {
    const ansText = canvasText || studentAnswerText;
    if (!ansText.trim() && !canvasDataUrl) return;
    if (!session) return;

    setIsLoading(true);
    const newHistory = [
      ...session.history,
      {
        question: session.currentQuestion,
        studentAnswer: ansText || 'Đã nộp bài giải qua nét vẽ bảng iPad',
      },
    ];

    try {
      const response = await aiFetch('/api/tutor/viva', {
        method: 'POST',
        body: JSON.stringify({
          chapterTitle: session.chapterTitle,
          mode: 'submit_answer',
          studentAnswer: ansText || 'Bài giải qua hình ảnh / nét vẽ bảng iPad',
          history: newHistory,
          imageBase64: canvasDataUrl,
        }),
      });

      const data = await response.json();
      if (data.success && data.data) {
        const result = data.data;
        const awardedScore = result.evaluation?.score ?? result.score ?? 8;
        const feedbackText = result.evaluation?.feedback || result.feedback || 'Giám khảo đã ghi nhận câu trả lời.';
        const gaps = result.evaluation?.knowledgeGaps || result.knowledgeGaps || [];

        const updatedHistory = [...session.history];
        updatedHistory.push({
          question: session.currentQuestion,
          studentAnswer: ansText || 'Bài giải hình ảnh bảng iPad',
          score: awardedScore,
          feedback: feedbackText,
          gaps,
        });

        setSession({
          ...session,
          history: updatedHistory,
          currentQuestion: result.nextQuestion || null,
          totalScore: session.totalScore + awardedScore,
        });

        onAddExp(awardedScore * 10);
        setStudentAnswerText('');

        if (gaps && gaps.length > 0) {
          onRecordMistake({
            id: `viva_gap_${Date.now()}`,
            chapterId: typeof selectedChapterId === 'number' ? selectedChapterId : 1,
            chapterTitle: session.chapterTitle,
            sourceType: 'viva',
            questionSummary: session.currentQuestion,
            studentAnswer: ansText,
            correctConcept: 'Lý thuyết chuẩn vấn đáp giáo sư',
            rootCauseError: gaps[0],
            remediationAdvice: feedbackText,
            timestamp: new Date().toLocaleTimeString(),
          });
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  // --- STUDENT ASKS AI HANDLERS (MULTIMODAL) ---
  const handleAskAI = async (canvasDataUrl?: string, canvasText?: string) => {
    const qText = canvasText || studentQuestionText.trim();
    const imgData = canvasDataUrl || attachedImageBase64;

    if (!qText && !imgData && !attachedFile) return;

    setIsLoading(true);

    try {
      const response = await aiFetch('/api/tutor/viva', {
        method: 'POST',
        body: JSON.stringify({
          chapterTitle: currentChapterTitle,
          mode: 'student_ask',
          studentQuestion: qText || (attachedFile ? `Giải đáp nội dung file ${attachedFile.name}` : 'Giải đáp hình ảnh/bảng iPad đính kèm'),
          imageBase64: imgData,
          fileMetadata: attachedFile ? { name: attachedFile.name, type: attachedFile.type } : undefined,
        }),
      });

      const data = await response.json();
      if (data.success && data.data) {
        setStudentQnAHistory((prev) => [
          ...prev,
          {
            question: qText || 'Câu hỏi bài tập qua hình ảnh / tệp đính kèm',
            image: imgData || undefined,
            fileName: attachedFile?.name,
            answer: data.data,
          },
        ]);

        setStudentQuestionText('');
        setAttachedImageBase64(null);
        setAttachedFile(null);
        onAddExp(20);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAttachedFile(file);

    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => setAttachedImageBase64(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const startVoiceInput = () => {
    setIsVoiceRecording(true);
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const rec = new SpeechRecognition();
      rec.lang = 'vi-VN';
      rec.interimResults = false;

      rec.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        if (vivaMode === 'student_mode') {
          setStudentQuestionText(text);
        } else {
          setStudentAnswerText(text);
        }
        setIsVoiceRecording(false);
      };

      rec.onerror = () => setIsVoiceRecording(false);
      rec.start();
    } else {
      setTimeout(() => {
        const sample = 'Thầy ơi, giải thích giúp em bài toán kiểm định giả thiết tỷ lệ này với ạ!';
        if (vivaMode === 'student_mode') {
          setStudentQuestionText(sample);
        } else {
          setStudentAnswerText(sample);
        }
        setIsVoiceRecording(false);
      }, 2000);
    }
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-2 border-cyan-500/40 p-6 rounded-3xl space-y-2 shadow-[0_0_25px_rgba(6,182,212,0.15)]">
        <div className="flex items-center gap-2 text-cyan-400 font-extrabold text-sm">
          <HelpCircle className="w-5 h-5 text-cyan-400" />
          <span>TÍNH NĂNG VẤN ĐÁP LÝ THUYẾT AI ĐA CHIỀU & ĐA PHƯƠNG THỨC</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white drop-shadow-[0_0_10px_rgba(6,182,212,0.4)]">
          Vấn Đáp Hai Chiều: Giám Khảo Khảo Sát & Sinh Viên Hỏi Thỏa Đáp Tri Thức
        </h2>
        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
          Bạn có thể để AI đóng vai Giám khảo vấn đáp, hoặc <strong className="text-cyan-300 font-bold">tự do gửi bất kỳ câu hỏi, bài tập, hình ảnh, file PDF/Word, chữ viết tay bảng iPad</strong> để Giáo Sư AI trực tiếp giải đáp cặn kẽ!
        </p>

        {/* Mode Selector Tabs */}
        <div className="flex flex-wrap items-center gap-2.5 pt-3">
          <button
            onClick={() => setVivaMode('examiner_mode')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              vivaMode === 'examiner_mode'
                ? 'bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 font-black shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                : 'bg-slate-900 text-slate-300 border border-slate-700 hover:border-cyan-400/50 hover:text-white'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>1. Giám Khảo AI Khảo Sát & Chấm Điểm</span>
          </button>

          <button
            onClick={() => setVivaMode('student_mode')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              vivaMode === 'student_mode'
                ? 'bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 font-black shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                : 'bg-slate-900 text-slate-300 border border-slate-700 hover:border-cyan-400/50 hover:text-white'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>2. Người Dùng Hỏi AI (Văn Bản, Viết Tay, Ảnh, File)</span>
          </button>
        </div>
      </div>

      {/* MODE 1: EXAMINER ASKS STUDENT */}
      {vivaMode === 'examiner_mode' && (
        <div className="space-y-6">
          <div className="bg-slate-900/90 border-2 border-cyan-500/30 p-5 rounded-3xl flex flex-wrap items-center justify-between gap-3 shadow-[0_0_20px_rgba(6,182,212,0.1)]">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-slate-200">Chủ đề vấn đáp:</span>
              <select
                value={selectedChapterId}
                onChange={(e) => setSelectedChapterId(e.target.value === 'all' ? 'all' : Number(e.target.value))}
                className="p-2.5 rounded-xl border border-cyan-500/30 bg-slate-950 text-white text-xs outline-none font-bold focus:border-cyan-400"
              >
                <option value="all">Toàn bộ 7 Chương XSTK</option>
                {CHAPTERS_DATA.map((c) => (
                  <option key={c.id} value={c.id}>
                    Chương {c.id}: {c.shortTitle}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleStartExaminerSession}
              disabled={isLoading}
              className="py-2.5 px-5 bg-gradient-to-r from-cyan-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 text-slate-950 font-black rounded-xl text-xs shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all flex items-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              <span>{isLoading ? 'Đang chuẩn bị câu hỏi...' : 'BẮT ĐẦU PHIÊN VẤN ĐÁP MỚI'}</span>
            </button>
          </div>

          {/* Session Conversation Thread */}
          {session && (
            <div className="space-y-4 animate-fade-in">
              {session.history.map((turn: any, i: number) => (
                <div key={i} className="space-y-2">
                  <div className="bg-slate-900 p-4 rounded-2xl border border-cyan-500/30 text-xs">
                    <span className="font-black text-cyan-300">👨‍🏫 Giám khảo AI hỏi #{i + 1}:</span>
                    <p className="mt-1 font-semibold text-white">{turn.question}</p>
                  </div>

                  <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-xs ml-4 space-y-2">
                    <span className="font-bold text-slate-400">💬 Câu trả lời của bạn:</span>
                    <p className="text-slate-100 font-medium">{turn.studentAnswer}</p>

                    {turn.score !== undefined && (
                      <div className="p-3 bg-slate-900 rounded-xl space-y-1.5 border border-cyan-500/30">
                        <div className="flex items-center justify-between font-bold text-emerald-300">
                          <span>Điểm đánh giá: {turn.score}/10 điểm</span>
                        </div>
                        <p className="text-slate-200">{turn.feedback}</p>

                        {turn.gaps && turn.gaps.length > 0 && (
                          <div className="p-2 bg-rose-950/80 text-rose-300 rounded-lg text-[11px] font-bold flex items-center gap-1.5 border border-rose-500/40">
                            <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                            <span>Lỗ hổng kiến thức: {turn.gaps.join(', ')}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {/* Active Question to Answer */}
              {session.currentQuestion && (
                <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-2 border-cyan-500/50 text-white p-6 rounded-3xl space-y-4 shadow-[0_0_25px_rgba(6,182,212,0.25)]">
                  <div className="flex items-center gap-2 font-black text-xs text-cyan-300">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    <span>CÂU HỎI VẤN ĐÁP ĐANG CHỜ TRẢ LỜI:</span>
                  </div>

                  <p className="text-base font-extrabold text-white">{session.currentQuestion}</p>

                  <div className="bg-slate-950 p-4 rounded-2xl border border-cyan-500/30 text-white space-y-3">
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-slate-300">Hình thức trả lời của bạn:</span>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => setUseCanvasDrawing(!useCanvasDrawing)}
                          className="px-3 py-1 bg-cyan-950 text-cyan-300 border border-cyan-500/40 rounded-lg text-[11px] font-bold hover:bg-cyan-900 transition-colors"
                        >
                          {useCanvasDrawing ? 'Chuyển sang gõ chữ' : '✍️ Bật viết tay iPad'}
                        </button>
                      </div>
                    </div>

                    {useCanvasDrawing ? (
                      <InteractiveCanvas
                        onExportCanvas={(dataUrl, text) => handleSubmitAnswerToExaminer(dataUrl, text)}
                        isSubmitting={isLoading}
                      />
                    ) : (
                      <div className="space-y-3">
                        <textarea
                          value={studentAnswerText}
                          onChange={(e) => setStudentAnswerText(e.target.value)}
                          placeholder="Nhập câu trả lời vấn đáp của bạn..."
                          className="w-full p-3 rounded-xl border border-cyan-500/30 bg-slate-900 text-white placeholder-slate-400 text-xs h-24 outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 resize-none font-medium"
                        />

                        <div className="flex items-center justify-between">
                          <button
                            type="button"
                            onClick={startVoiceInput}
                            className={`p-2.5 rounded-xl text-white transition-colors flex items-center gap-1.5 text-xs font-bold ${
                              isVoiceRecording ? 'bg-rose-500 animate-ping' : 'bg-slate-800 hover:bg-slate-700 border border-slate-700'
                            }`}
                          >
                            <Mic className="w-4 h-4 text-cyan-400" />
                            <span>{isVoiceRecording ? 'Đang nghe...' : 'Nói câu trả lời'}</span>
                          </button>

                          <button
                            onClick={() => handleSubmitAnswerToExaminer()}
                            disabled={isLoading || !studentAnswerText.trim()}
                            className="py-2.5 px-6 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black rounded-xl text-xs shadow-[0_0_15px_rgba(16,185,129,0.4)] flex items-center gap-1.5 transition-all"
                          >
                            <Send className="w-4 h-4" />
                            <span>{isLoading ? 'Giám khảo đang chấm...' : 'NỘP CÂU TRẢ LỜI VẤN ĐÁP'}</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* MODE 2: STUDENT ASKS AI (MULTIMODAL: TEXT, DRAWING, IMAGE, FILE) */}
      {vivaMode === 'student_mode' && (
        <div className="space-y-6">
          {/* Multimodal Asking Input Box */}
          <div className="bg-slate-900/90 border-2 border-cyan-500/30 p-6 rounded-3xl space-y-4 shadow-[0_0_20px_rgba(6,182,212,0.1)]">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2 font-black text-cyan-300 text-xs">
                <BookOpen className="w-4 h-4 text-cyan-400" />
                <span>GỬI CÂU HỎI / BÀI TẬP BẤT KỲ ĐỂ GIÁO SƯ AI GIẢI ĐÁP & CHIA SẺ TRI THỨC</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setUseCanvasDrawing(!useCanvasDrawing)}
                  className="px-3 py-1.5 bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-bold rounded-xl text-xs hover:bg-cyan-900 transition-colors"
                >
                  {useCanvasDrawing ? 'Tắt Bảng Viết Tay' : '✍️ Viết Tay Lên Bảng iPad'}
                </button>
              </div>
            </div>

            {useCanvasDrawing ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-300">
                  Vẽ công thức hoặc bài toán bằng chuột/stylus, sau đó bấm nộp để AI phân tích giải đáp:
                </p>
                <InteractiveCanvas
                  onExportCanvas={(dataUrl, text) => handleAskAI(dataUrl, text)}
                  isSubmitting={isLoading}
                />
              </div>
            ) : (
              <div className="space-y-3">
                <textarea
                  value={studentQuestionText}
                  onChange={(e) => setStudentQuestionText(e.target.value)}
                  placeholder="Hỏi bất kỳ điều gì: lý thuyết, thắc mắc bài giảng, giải bài toán kinh tế, công thức Bayes, phân phối..."
                  className="w-full p-3.5 rounded-2xl border border-cyan-500/30 bg-slate-950 text-white placeholder-slate-400 text-xs h-28 outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 resize-none font-medium"
                />

                {/* Multimodal Attachments Strip */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <div className="flex items-center gap-2">
                    {/* File / Image Upload Input */}
                    <label className="cursor-pointer py-2 px-3 bg-slate-950 hover:bg-slate-800 text-slate-200 border border-cyan-500/30 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5">
                      <Upload className="w-4 h-4 text-cyan-400" />
                      <span>{attachedFile ? attachedFile.name : 'Đính Kèm Ảnh / PDF / File'}</span>
                      <input
                        type="file"
                        accept="image/*,.pdf,.doc,.docx,.txt"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>

                    {/* Voice Mic Button */}
                    <button
                      type="button"
                      onClick={startVoiceInput}
                      className={`p-2 rounded-xl text-white transition-colors flex items-center gap-1 text-xs font-bold ${
                        isVoiceRecording ? 'bg-rose-500 animate-ping' : 'bg-slate-800 hover:bg-slate-700 border border-slate-700'
                      }`}
                      title="Nói câu hỏi bằng Giọng Nói"
                    >
                      <Mic className="w-4 h-4 text-cyan-400" />
                      <span className="hidden sm:inline">Hỏi bằng giọng nói</span>
                    </button>
                  </div>

                  {/* Send Button */}
                  <button
                    onClick={() => handleAskAI()}
                    disabled={isLoading || (!studentQuestionText.trim() && !attachedImageBase64 && !attachedFile)}
                    className="py-2.5 px-6 bg-gradient-to-r from-cyan-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 disabled:opacity-50 text-slate-950 font-black rounded-xl text-xs shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all flex items-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isLoading ? 'Giáo sư AI đang giải đáp...' : 'GỬI CÂU HỎI CHO GIÁO SƯ AI'}</span>
                  </button>
                </div>

                {/* Image Preview if uploaded */}
                {attachedImageBase64 && (
                  <div className="p-2 bg-slate-950 rounded-xl max-w-xs border border-cyan-500/30">
                    <p className="text-[10px] text-cyan-300 mb-1 font-bold">Ảnh bài tập đã đính kèm:</p>
                    <img src={attachedImageBase64} alt="Đính kèm" className="rounded max-h-32 object-contain" />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Q&A Exchange History */}
          {studentQnAHistory.length > 0 && (
            <div className="space-y-4 animate-fade-in">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-cyan-400">
                Lịch Sử Giải Đáp & Chia Sẻ Tri Thức Với Giáo Sư AI
              </h3>

              {studentQnAHistory.map((item, idx) => (
                <div
                  key={idx}
                  className="bg-slate-900 border-2 border-cyan-500/30 p-6 rounded-3xl space-y-4 shadow-[0_0_20px_rgba(6,182,212,0.15)]"
                >
                  {/* Question */}
                  <div className="flex items-start gap-2.5 text-xs">
                    <span className="p-1.5 bg-cyan-500 text-slate-950 rounded-lg font-black">Hỏi</span>
                    <div className="space-y-1">
                      <p className="font-bold text-white">{item.question}</p>
                      {item.fileName && (
                        <span className="text-[10px] font-mono bg-slate-950 px-2 py-0.5 rounded text-cyan-400 border border-slate-700">
                          Tệp: {item.fileName}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* AI Explanation & Lecture */}
                  <div className="p-5 bg-slate-950 rounded-2xl border border-cyan-500/30 text-xs space-y-3">
                    <div className="flex items-center gap-2 font-black text-cyan-300 text-xs">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      <span>Bài Giảng Giải Thích & Thỏa Đáp Từ Giáo Sư AI:</span>
                    </div>

                    <div className="text-slate-100 leading-relaxed font-medium">
                      <MathText text={item.answer.teacherExplanation} />
                    </div>

                    {item.answer.suggestedFormulas && item.answer.suggestedFormulas.length > 0 && (
                      <div className="p-3 bg-slate-900 rounded-xl border border-cyan-500/30 space-y-1">
                        <span className="font-bold text-cyan-300 text-[11px]">
                          📐 Công thức toán học liên quan:
                        </span>
                        <div className="flex flex-wrap gap-2 pt-1">
                          {item.answer.suggestedFormulas.map((f, i) => (
                            <span key={i} className="font-mono bg-slate-950 px-2.5 py-1 rounded text-cyan-300 font-bold border border-cyan-500/40">
                              <MathFormula math={f} />
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {item.answer.followUpCheckQuestion && (
                      <div className="p-3 bg-emerald-950/60 rounded-xl border border-emerald-500/40 text-emerald-300 text-[11px] font-medium flex items-start gap-1.5">
                        <span className="font-bold shrink-0">❓ Câu hỏi củng cố của Thầy:</span>
                        <span className="flex-1"><MathText text={item.answer.followUpCheckQuestion} inline /></span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
