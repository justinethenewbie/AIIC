import React, { useState } from 'react';
import { FileText, Sparkles, Lightbulb, Sliders, CheckCircle2, RefreshCw, FileDown, Printer, Award, AlertCircle } from 'lucide-react';
import { CHAPTERS_DATA } from '../data/curriculumData';
import { InteractiveCanvas } from './InteractiveCanvas';
import { MathFormula, MathText } from './MathFormula';
import { exportExercisesToWord, exportExercisesToPdf } from '../utils/exportUtils';
import { aiFetch } from '../utils/apiHelper';

interface EssayPracticeProps {
  onAddExp: (amount: number) => void;
}

export const EssayPractice: React.FC<EssayPracticeProps> = ({ onAddExp }) => {
  // Config form state
  const [selectedChapterId, setSelectedChapterId] = useState<number | 'all'>('all');
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [difficulty, setDifficulty] = useState<'Cơ bản' | 'Trung bình' | 'Vận dụng' | 'Vận dụng cao'>('Vận dụng');
  const [focusType, setFocusType] = useState<
    'Bài toán thực tế kinh tế & ngân hàng' | 'Lập luận chứng minh & Biến cố' | 'Bảng số liệu phân phối tần số' | 'Kiểm định & Ước lượng mẫu'
  >('Bài toán thực tế kinh tế & ngân hàng');
  const [userExpectations, setUserExpectations] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [essayList, setEssayList] = useState<any[]>([]);

  // Export config state
  const [includeSolutionsInExport, setIncludeSolutionsInExport] = useState(true);

  // Submission state
  const [activeEssayIdx, setActiveEssayIdx] = useState(0);
  const [evaluationResult, setEvaluationResult] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [generationNotice, setGenerationNotice] = useState<string | null>(null);

  const handleExportWord = () => {
    if (essayList.length === 0) return;
    const chTitle =
      selectedChapterId === 'all'
        ? 'Toàn bộ 7 Chương XSTK Tổng Hợp'
        : CHAPTERS_DATA.find((c) => c.id === selectedChapterId)?.title || 'XSTK';

    exportExercisesToWord({
      title: `ĐỀ THI TỰ LUẬN XSTK - ${essayList.length} BÀI TOÁN`,
      subject: 'MÔN: XÁC SUẤT VÀ THỐNG KÊ TOÁN',
      chapterTitle: chTitle,
      difficulty,
      exercises: essayList.map((e) => ({
        question: e.question,
        title: e.title,
        strategyHint: e.strategyHint,
        keyFormulas: e.keyFormulas,
        expectedAnswerSummary: e.expectedAnswerSummary,
      })),
      isMcq: false,
      includeSolutions: includeSolutionsInExport,
    });
  };

  const handleExportPdf = () => {
    if (essayList.length === 0) return;
    const chTitle =
      selectedChapterId === 'all'
        ? 'Toàn bộ 7 Chương XSTK Tổng Hợp'
        : CHAPTERS_DATA.find((c) => c.id === selectedChapterId)?.title || 'XSTK';

    exportExercisesToPdf({
      title: `ĐỀ THI TỰ LUẬN XSTK - ${essayList.length} BÀI TOÁN`,
      subject: 'MÔN: XÁC SUẤT VÀ THỐNG KÊ TOÁN',
      chapterTitle: chTitle,
      difficulty,
      exercises: essayList.map((e) => ({
        question: e.question,
        title: e.title,
        strategyHint: e.strategyHint,
        keyFormulas: e.keyFormulas,
        expectedAnswerSummary: e.expectedAnswerSummary,
      })),
      isMcq: false,
      includeSolutions: includeSolutionsInExport,
    });
  };

  const handleGenerateCustomEssays = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsLoading(true);
    setEvaluationResult(null);
    setGenerationNotice(null);

    const chTitle =
      selectedChapterId === 'all'
        ? 'Toàn bộ 7 Chương Xác Suất Thống Kê Tổng Hợp'
        : CHAPTERS_DATA.find((c) => c.id === selectedChapterId)?.title || 'XSTK';

    try {
      const response = await aiFetch('/api/tutor/generate-similar', {
        method: 'POST',
        body: JSON.stringify({
          chapterId: selectedChapterId,
          chapterTitle: chTitle,
          type: 'essay',
          count: questionCount,
          difficulty,
          focusType,
          userExpectations,
        }),
      });

      const data = await response.json();
      if (data.success && data.exercises && data.exercises.length > 0) {
        setEssayList(data.exercises);
        setActiveEssayIdx(0);
        onAddExp(30);
        if (data.isAiGenerated) {
          setGenerationNotice('✨ Đề thi tự luận đã được sinh trực tiếp bằng Google Gemini AI theo đúng yêu cầu của bạn!');
        } else if (data.notice) {
          setGenerationNotice(data.notice);
        }
      } else {
        alert(data.error || 'Hệ thống đang chuẩn bị bộ đề theo yêu cầu, vui lòng thử lại!');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGradeEssaySubmission = async (dataUrl: string, typedText: string) => {
    const curEssay = essayList[activeEssayIdx];
    if (!curEssay) return;

    setIsSubmitting(true);
    setEvaluationResult(null);

    try {
      const response = await aiFetch('/api/tutor/evaluate', {
        method: 'POST',
        body: JSON.stringify({
          imageBase64: dataUrl,
          textContent: `Đề bài: "${curEssay.question}"\nBài làm của sinh viên: "${typedText}"`,
          chapterTitle: 'Bài tập tự luận do AI sinh theo yêu cầu',
          strategyOnly: false,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setEvaluationResult(data.data);
        onAddExp(50);
      } else if (data.needsApiKey) {
        alert('⚠️ ' + data.error);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };
  };

  const currentEssay = essayList[activeEssayIdx];

  return (
    <div className="space-y-6 text-slate-100">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-2 border-cyan-500/40 p-6 rounded-3xl space-y-2 shadow-[0_0_25px_rgba(6,182,212,0.15)]">
        <div className="flex items-center gap-2 text-cyan-400 font-extrabold text-sm">
          <FileText className="w-5 h-5 text-cyan-400" />
          <span>TRÌNH TẠO ĐỀ THI TỰ LUẬN AI CÁ NHÂN HÓA TOÀN DIỆN</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white drop-shadow-[0_0_10px_rgba(6,182,212,0.4)]">
          Thiết Lập Đề Thi Tự Luận XSTK Theo Đúng Ý Muốn Của Bạn
        </h2>
        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
          Tùy chọn chủ đề, số lượng câu hỏi, mức độ khó và kỳ vọng cụ thể. AI sẽ sinh đề thi ngay lập tức, cung cấp chiến lược giải từng bước và hỗ trợ làm bài trực tiếp trên bảng iPad!
        </p>
      </div>

      {/* Setup Form */}
      <form onSubmit={handleGenerateCustomEssays} className="bg-slate-900/90 border-2 border-cyan-500/30 p-6 rounded-3xl space-y-4 shadow-[0_0_20px_rgba(6,182,212,0.1)]">
        <div className="flex items-center gap-2 font-black text-cyan-300 text-xs border-b border-slate-800 pb-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <span>BẢNG THIẾT LẬP THÔNG SỐ ĐỀ THI TỰ LUẬN</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          {/* Topic Select */}
          <div>
            <label className="block text-slate-200 font-bold mb-1.5">
              1. Chủ đề / Chương muốn hỏi:
            </label>
            <select
              value={selectedChapterId}
              onChange={(e) => setSelectedChapterId(e.target.value === 'all' ? 'all' : Number(e.target.value))}
              className="w-full p-3 rounded-xl border border-cyan-500/30 bg-slate-950 text-white font-semibold outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all"
            >
              <option value="all">Toàn bộ 7 Chương (Tổng hợp)</option>
              {CHAPTERS_DATA.map((c) => (
                <option key={c.id} value={c.id}>
                  Chương {c.id}: {c.shortTitle}
                </option>
              ))}
            </select>
          </div>

          {/* Question Count */}
          <div>
            <label className="block text-slate-200 font-bold mb-1.5">
              2. Số lượng bài toán tự luận:
            </label>
            <select
              value={questionCount}
              onChange={(e) => setQuestionCount(Number(e.target.value))}
              className="w-full p-3 rounded-xl border border-cyan-500/30 bg-slate-950 text-white font-semibold outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all"
            >
              <option value={3}>3 bài toán (Luyện nhanh 20p)</option>
              <option value={5}>5 bài toán (Đề tự luyện chuẩn 45p)</option>
              <option value={8}>8 bài toán (Đề ôn tập giữa kỳ)</option>
              <option value={10}>10 bài toán (Đề tổng ôn toàn diện 90p)</option>
            </select>
          </div>

          {/* Difficulty Level */}
          <div>
            <label className="block text-slate-200 font-bold mb-1.5">
              3. Mức độ câu hỏi:
            </label>
            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value as any)}
              className="w-full p-3 rounded-xl border border-cyan-500/30 bg-slate-950 text-white font-semibold outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all"
            >
              <option value="Cơ bản">Cơ bản (Áp dụng công thức trực tiếp)</option>
              <option value="Trung bình">Trung bình (Phân tích biến cố)</option>
              <option value="Vận dụng">Vận dụng (Bài toán thực tế kinh tế)</option>
              <option value="Vận dụng cao">Vận dụng cao (Phân hóa 9-10đ thi cử)</option>
            </select>
          </div>

          {/* Focus Type */}
          <div>
            <label className="block text-slate-200 font-bold mb-1.5">
              4. Trọng tâm hình thức:
            </label>
            <select
              value={focusType}
              onChange={(e) => setFocusType(e.target.value as any)}
              className="w-full p-3 rounded-xl border border-cyan-500/30 bg-slate-950 text-white font-semibold outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all"
            >
              <option value="Bài toán thực tế kinh tế & ngân hàng">Thực tế Kinh tế & Ngân hàng</option>
              <option value="Lập luận chứng minh & Biến cố">Phân tích biến cố & Xác suất điều kiện</option>
              <option value="Bảng số liệu phân phối tần số">Bảng số liệu tần số & Số đặc trưng</option>
              <option value="Kiểm định & Ước lượng mẫu">Ước lượng & Kiểm định giả thiết</option>
            </select>
          </div>
        </div>

        {/* User specific expectations */}
        <div>
          <label className="block text-xs text-slate-200 font-bold mb-1.5">
            5. Yêu cầu & Kỳ vọng riêng của bạn (Tùy chọn):
          </label>
          <input
            type="text"
            value={userExpectations}
            onChange={(e) => setUserExpectations(e.target.value)}
            placeholder="Ví dụ: Cần bài toán tính tỷ lệ thu hồi nợ xấu, hàm mật độ liên tục, tìm hằng số k và phương sai..."
            className="w-full p-3 rounded-xl border border-cyan-500/30 bg-slate-950 text-white placeholder-slate-400 text-xs outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 font-medium"
          />
        </div>

        {/* Action Button */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full py-3.5 bg-gradient-to-r from-cyan-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 disabled:opacity-50 text-slate-950 font-black rounded-2xl shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all text-xs flex items-center justify-center gap-2 cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-slate-950" />
          <span>{isLoading ? `AI đang tạo ${questionCount} bài toán tự luận theo yêu cầu...` : `TẠO NGAY BỘ ĐỀ TỰ LUẬN (${questionCount} BÀI TOÁN)`}</span>
        </button>

        {generationNotice && (
          <div className="p-3 bg-cyan-950/70 border border-cyan-500/40 rounded-xl text-xs text-cyan-200 flex items-center gap-2 animate-fade-in font-medium">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>{generationNotice}</span>
          </div>
        )}
      </form>

      {/* Render Essay Problem Workspace */}
      {essayList.length > 0 && currentEssay && (
        <div className="space-y-6 animate-fade-in">
          {/* Export Action Bar (Word & PDF) */}
          <div className="p-4 bg-slate-900 border-2 border-cyan-500/30 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-[0_0_20px_rgba(6,182,212,0.2)]">
            <div className="flex items-center gap-2.5">
              <span className="p-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                <FileDown className="w-5 h-5 text-cyan-400" />
              </span>
              <div>
                <p className="text-xs font-black text-white">Trích Xuất Đề Thi Tự Luận Ra File (Word / PDF)</p>
                <p className="text-[11px] text-slate-300 font-medium">Bộ đề gồm {essayList.length} bài toán tự luận có gợi ý chiến lược & barem điểm</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <label className="flex items-center gap-1.5 text-xs text-slate-200 cursor-pointer font-bold">
                <input
                  type="checkbox"
                  checked={includeSolutionsInExport}
                  onChange={(e) => setIncludeSolutionsInExport(e.target.checked)}
                  className="rounded border-cyan-500 text-cyan-500 focus:ring-cyan-400"
                />
                <span>Kèm chiến lược giải & công thức</span>
              </label>

              <button
                type="button"
                onClick={handleExportWord}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-1.5 transition-all"
                title="Tải đề thi tự luận dạng file Microsoft Word (.doc)"
              >
                <FileText className="w-4 h-4" />
                <span>Xuất Word (.doc)</span>
              </button>

              <button
                type="button"
                onClick={handleExportPdf}
                className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-1.5 transition-all"
                title="In hoặc Lưu thành file PDF chuẩn A4"
              >
                <Printer className="w-4 h-4" />
                <span>Xuất PDF</span>
              </button>
            </div>
          </div>

          {/* Question Selector Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
            {essayList.map((essay, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setActiveEssayIdx(idx);
                  setEvaluationResult(null);
                }}
                className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  activeEssayIdx === idx
                    ? 'bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 font-black shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                    : 'bg-slate-900 text-slate-300 border border-slate-700 hover:border-cyan-400/50 hover:text-white'
                }`}
              >
                Bài toán #{idx + 1}
              </button>
            ))}
          </div>

          {/* Current Essay Problem Card */}
          <div className="bg-slate-900 border-2 border-cyan-500/30 p-6 rounded-3xl space-y-4 shadow-[0_0_20px_rgba(6,182,212,0.15)]">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <span className="font-black text-cyan-300 text-sm">
                Bài toán #{activeEssayIdx + 1}: {currentEssay.title || `Bài tập tự luận ${activeEssayIdx + 1}`}
              </span>
              <span className="text-[10px] font-mono bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 font-bold px-2.5 py-1 rounded-lg">
                Chiến Lược Giải & Barem Rubric
              </span>
            </div>

            <div className="text-xs sm:text-sm text-white font-medium leading-relaxed">
              <MathText text={currentEssay.question} />
            </div>

            {/* Strategy Hint Box */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-cyan-500/30 space-y-2 text-xs">
              <div className="flex items-center gap-1.5 font-black text-cyan-300">
                <Lightbulb className="w-4 h-4 text-cyan-400" />
                <span>Gợi ý chiến lược định hướng từng bước giải từ AI:</span>
              </div>
              <div className="text-slate-200 leading-relaxed font-medium">
                <MathText text={currentEssay.strategyHint} />
              </div>

              {currentEssay.keyFormulas && currentEssay.keyFormulas.length > 0 && (
                <div className="pt-2 flex flex-wrap gap-2 items-center">
                  <span className="font-bold text-[11px] text-slate-300">Công thức cần dùng:</span>
                  {currentEssay.keyFormulas.map((f: string, i: number) => (
                    <span key={i} className="font-mono bg-slate-900 px-2.5 py-1 rounded-lg border border-cyan-500/40 text-cyan-300 font-bold text-[11px]">
                      <MathFormula math={f} />
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Interactive iPad Canvas to write/type solution */}
            <div className="pt-2">
              <InteractiveCanvas
                onExportCanvas={handleGradeEssaySubmission}
                isSubmitting={isSubmitting}
              />
            </div>

            {/* AI Grading Result */}
            {evaluationResult && (
              <div className="p-5 bg-slate-950 border-2 border-emerald-400/70 rounded-3xl text-xs space-y-3 animate-fade-in shadow-[0_0_20px_rgba(16,185,129,0.3)]">
                <div className="flex items-center justify-between font-black text-emerald-300 text-sm">
                  <span>Kết Quả Chấm Điểm AI Tutor:</span>
                  <span className="font-mono text-base">{evaluationResult.totalScore} / 10 điểm</span>
                </div>
                <p className="text-slate-100 leading-relaxed font-semibold">
                  {evaluationResult.detailedFeedback}
                </p>
                {evaluationResult.betterStrategy && (
                  <div className="p-3 bg-slate-900 rounded-xl border border-emerald-500/40">
                    <p className="font-bold text-emerald-300 mb-0.5 flex items-center gap-1">
                      <Award className="w-3.5 h-3.5" />
                      <span>Lời khuyên tối ưu bước giải:</span>
                    </p>
                    <p className="text-slate-200">{evaluationResult.betterStrategy}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
