import React, { useMemo } from 'react';
import katex from 'katex';

interface MathFormulaProps {
  math: string;
  block?: boolean;
  className?: string;
}

/**
 * Clean up common artifacts in LaTeX math strings
 */
function cleanLatexString(raw: string): string {
  if (!raw) return '';
  return raw
    .trim()
    .replace(/\\\\/g, '\\')
    .replace(/\\/g, '\\');
}

/**
 * Safely render a LaTeX math formula via KaTeX
 */
export function renderKatexSafe(mathStr: string, isBlock = false): string {
  try {
    const clean = cleanLatexString(mathStr);
    return katex.renderToString(clean, {
      displayMode: isBlock,
      throwOnError: false,
      strict: false,
    });
  } catch (err) {
    return mathStr;
  }
}

/**
 * Component for dedicated math expressions
 */
export const MathFormula: React.FC<MathFormulaProps> = ({
  math,
  block = false,
  className = '',
}) => {
  const html = useMemo(() => {
    if (!math) return '';
    return renderKatexSafe(math, block);
  }, [math, block]);

  if (block) {
    return (
      <div
        className={`my-2.5 overflow-x-auto text-center py-2.5 px-4 bg-slate-950/90 rounded-2xl border-2 border-cyan-500/40 text-cyan-200 shadow-[0_0_15px_rgba(6,182,212,0.15)] text-sm font-mono ${className}`}
        dangerouslySetInnerHTML={{ __html: html }}
      />
    );
  }

  return (
    <span
      className={`inline-block mx-0.5 font-mono text-cyan-300 font-semibold align-middle ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};

export interface MathSegment {
  type: 'text' | 'math';
  content: string;
  isBlock?: boolean;
  html?: string;
}

/**
 * Parse any mixed Vietnamese text containing LaTeX math formulas (with or without $ delimiters)
 */
export function parseMathSegments(text: string): MathSegment[] {
  if (!text) return [];

  // Regex pattern matching:
  // 1. $$...$$ block math
  // 2. $...$ inline math
  // 3. \frac{...}{...} fractions with optional left-hand side (e.g., P(A) = \frac{n_A}{n_\Omega}, Z = \frac{X - \mu}{\sigma})
  // 4. Other common LaTeX commands: \int, \sum, \sqrt, \prod, \lim, \Phi, \sigma, \mu, \lambda, \alpha, \beta, \Omega, \bar, \hat, \sim, \le, \ge
  const mathPattern = /(\$\$[\s\S]*?\$\$|\$[^\$\n]+?\$|(?:\b[A-Za-z0-9_()]+\s*=\s*)?\\frac\{(?:[^{}]+|\{[^{}]*\})*\}\{(?:[^{}]+|\{[^{}]*\})*\}|(?:\b[A-Za-z0-9_()]+\s*=\s*)?\\(?:int|sum|sqrt|prod|lim|Phi|sigma|mu|lambda|alpha|beta|Omega|bar|hat|vec)\b(?:[^{}\s,;.!?]|(?:\{[^{}]*\}))*)/g;

  const segments: MathSegment[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = mathPattern.exec(text)) !== null) {
    if (match.index > lastIndex) {
      segments.push({
        type: 'text',
        content: text.slice(lastIndex, match.index),
      });
    }

    const raw = match[0];
    let isBlock = false;
    let mathContent = raw;

    if (raw.startsWith('$$') && raw.endsWith('$$')) {
      isBlock = true;
      mathContent = raw.slice(2, -2);
    } else if (raw.startsWith('$') && raw.endsWith('$')) {
      isBlock = false;
      mathContent = raw.slice(1, -1);
    }

    segments.push({
      type: 'math',
      content: mathContent,
      isBlock,
      html: renderKatexSafe(mathContent, isBlock),
    });

    lastIndex = match.index + raw.length;
  }

  if (lastIndex < text.length) {
    segments.push({
      type: 'text',
      content: text.slice(lastIndex),
    });
  }

  return segments;
}

/**
 * Universal component that takes any string (plain Vietnamese text, paragraphs, LaTeX formulas)
 * and formats math formulas seamlessly using KaTeX without breaking the surrounding text.
 */
export const MathText: React.FC<{
  text: string;
  className?: string;
  inline?: boolean;
}> = ({ text, className = '', inline = false }) => {
  const segments = useMemo(() => parseMathSegments(text), [text]);

  if (!text) return null;

  // Render segments preserving lines and whitespace
  const content = segments.map((seg, idx) => {
    if (seg.type === 'math') {
      if (seg.isBlock && !inline) {
        return (
          <div
            key={idx}
            className="my-2 text-center overflow-x-auto py-1 px-2 text-cyan-200"
            dangerouslySetInnerHTML={{ __html: seg.html || seg.content }}
          />
        );
      }
      return (
        <span
          key={idx}
          className="inline-block mx-0.5 text-cyan-300 font-mono font-medium align-middle"
          dangerouslySetInnerHTML={{ __html: seg.html || seg.content }}
        />
      );
    }

    // Text segment: split by line breaks to preserve formatting
    const lines = seg.content.split('\n');
    return (
      <span key={idx}>
        {lines.map((line, lIdx) => (
          <React.Fragment key={lIdx}>
            {line}
            {lIdx < lines.length - 1 && <br />}
          </React.Fragment>
        ))}
      </span>
    );
  });

  if (inline) {
    return <span className={className}>{content}</span>;
  }

  return <div className={`leading-relaxed ${className}`}>{content}</div>;
};

/**
 * Render mixed text into pure HTML with embedded KaTeX spans for export documents (PDF/Word)
 */
export function renderMathToHtml(text: string): string {
  if (!text) return '';
  const segments = parseMathSegments(text);
  return segments
    .map((seg) => {
      if (seg.type === 'math') {
        return seg.html || seg.content;
      }
      return seg.content.replace(/\n/g, '<br>');
    })
    .join('');
}
