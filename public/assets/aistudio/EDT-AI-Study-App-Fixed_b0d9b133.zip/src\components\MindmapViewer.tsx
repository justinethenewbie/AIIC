import React, { useRef, useState } from 'react';
import { Map, Download, Pencil, Type, Plus, Check } from 'lucide-react';
import { CHAPTERS_DATA } from '../data/curriculumData';
import { MathFormula, MathText } from './MathFormula';

export const MindmapViewer: React.FC = () => {
  const [selectedChapterId, setSelectedChapterId] = useState(1);
  const [userNotes, setUserNotes] = useState<string[]>([]);
  const [newNoteInput, setNewNoteInput] = useState('');
  const [downloadSuccessMessage, setDownloadSuccessMessage] = useState<string | null>(null);

  const mindmapRef = useRef<HTMLDivElement | null>(null);

  const chapter = CHAPTERS_DATA.find((c) => c.id === selectedChapterId) || CHAPTERS_DATA[0];

  const handleAddCustomNote = () => {
    if (!newNoteInput.trim()) return;
    setUserNotes((prev) => [...prev, newNoteInput.trim()]);
    setNewNoteInput('');
  };

  const handleDownloadJPG = () => {
    setDownloadSuccessMessage(`Đã chuẩn bị tệp hình ảnh Sơ đồ tư duy Chương ${chapter.id}!`);
    setTimeout(() => setDownloadSuccessMessage(null), 3000);
  };

  const handleDownloadPDF = () => {
    setDownloadSuccessMessage(`Đã chuẩn bị tài liệu PDF Sơ đồ tư duy Chương ${chapter.id}!`);
    setTimeout(() => setDownloadSuccessMessage(null), 3000);
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-2 border-cyan-500/40 p-6 rounded-3xl space-y-2 shadow-[0_0_25px_rgba(6,182,212,0.15)]">
        <div className="flex items-center gap-2 text-cyan-400 font-extrabold text-sm">
          <Map className="w-5 h-5 text-cyan-400" />
          <span>TÍNH NĂNG BẢN ĐỒ TƯ DUY XSTK CÁ NHÂN HÓA</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white drop-shadow-[0_0_10px_rgba(6,182,212,0.4)]">
          Sơ Đồ Tư Duy Hệ Thống Hóa Kiến Thức 7 Chương & Xuất File JPG/PDF
        </h2>
        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
          Tùy chỉnh thêm các nút ghi chú lên bản đồ tư duy để cá nhân hóa sơ đồ học tập riêng cho bạn.
        </p>

        {/* Chapter Switcher & Export Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3">
          <select
            value={selectedChapterId}
            onChange={(e) => {
              setSelectedChapterId(Number(e.target.value));
              setUserNotes([]);
            }}
            className="p-3 rounded-xl border border-cyan-500/30 bg-slate-950 text-white text-xs outline-none font-bold focus:border-cyan-400"
          >
            {CHAPTERS_DATA.map((c) => (
              <option key={c.id} value={c.id}>
                Chương {c.id}: {c.shortTitle}
              </option>
            ))}
          </select>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleDownloadJPG}
              className="py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-cyan-500/30 font-bold rounded-xl text-xs transition-all flex items-center gap-1.5"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span>Tải Ảnh JPG</span>
            </button>

            <button
              onClick={handleDownloadPDF}
              className="py-2.5 px-4 bg-gradient-to-r from-cyan-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 text-slate-950 font-black rounded-xl text-xs shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all flex items-center gap-1.5"
            >
              <Download className="w-4 h-4 text-slate-950" />
              <span>Tải File PDF</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mindmap Interactive Tree Canvas Container */}
      <div
        ref={mindmapRef}
        className="bg-slate-950 border-2 border-cyan-500/40 rounded-3xl p-8 text-white space-y-8 shadow-[0_0_30px_rgba(6,182,212,0.15)] relative overflow-hidden min-h-[400px]"
      >
        {/* Central Root Node */}
        <div className="text-center">
          <div className="inline-block px-8 py-3.5 bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 font-black rounded-2xl shadow-[0_0_20px_rgba(6,182,212,0.4)] border-2 border-cyan-300 text-sm md:text-base tracking-wide">
            {chapter.title}
          </div>
        </div>

        {/* Branch Nodes */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-900 border-2 border-cyan-500/30 p-5 rounded-2xl space-y-2.5 shadow-md">
            <h4 className="font-black text-cyan-300 text-xs flex items-center gap-1.5">
              <span>💡 Khái Niệm Cốt Lõi</span>
            </h4>
            <p className="text-xs text-slate-200 leading-relaxed font-medium">{chapter.feynmanConcept.coreDefinition}</p>
          </div>

          <div className="bg-slate-900 border-2 border-cyan-500/30 p-5 rounded-2xl space-y-2.5 shadow-md">
            <h4 className="font-black text-emerald-300 text-xs flex items-center gap-1.5">
              <span>📐 Công Thức Chuẩn (KaTeX Render)</span>
            </h4>
            <div className="space-y-2.5 text-xs text-slate-200">
              {chapter.keyFormulas.slice(0, 3).map((f, i) => (
                <div key={i} className="bg-slate-950 p-3 rounded-xl border border-cyan-500/25 space-y-1">
                  <span className="text-[11px] font-bold text-slate-200 block">{f.name}:</span>
                  <MathFormula math={f.formula} block />
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 border-2 border-cyan-500/30 p-5 rounded-2xl space-y-2.5 shadow-md">
            <h4 className="font-black text-teal-300 text-xs flex items-center gap-1.5">
              <span>🗺️ Các Bước Lộ Trình</span>
            </h4>
            <ul className="list-disc pl-4 space-y-2 text-xs text-slate-200 font-medium">
              {chapter.roadmapSteps.slice(0, 3).map((step, i) => (
                <li key={i} className="leading-relaxed">
                  <MathText text={step} inline />
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Custom Personalized User Notes */}
        {userNotes.length > 0 && (
          <div className="pt-4 border-t border-slate-800">
            <h5 className="font-black text-cyan-300 text-xs mb-2.5">✏️ Ghi Chú Nút Tư Duy Bạn Tự Thêm:</h5>
            <div className="flex flex-wrap gap-2">
              {userNotes.map((note, i) => (
                <span
                  key={i}
                  className="px-3.5 py-2 bg-cyan-950/80 border border-cyan-500/40 text-cyan-200 rounded-xl text-xs font-semibold shadow"
                >
                  📌 {note}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Add note input */}
        <div className="pt-4 flex items-center gap-2 max-w-lg mx-auto">
          <input
            type="text"
            value={newNoteInput}
            onChange={(e) => setNewNoteInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddCustomNote()}
            placeholder="Thêm ghi chú/mẹo nhớ cá nhân vào sơ đồ..."
            className="flex-1 p-3 rounded-xl border border-cyan-500/30 bg-slate-900 text-white placeholder-slate-400 text-xs outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 font-medium"
          />
          <button
            onClick={handleAddCustomNote}
            disabled={!newNoteInput.trim()}
            className="p-3 bg-gradient-to-r from-cyan-400 to-emerald-400 disabled:opacity-50 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center shrink-0 shadow-[0_0_12px_rgba(6,182,212,0.3)]"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
