import React, { useState } from 'react';
import { X, Lock, Mail, User, Shield, GraduationCap, CheckCircle2, Sparkles, ArrowRight, Database } from 'lucide-react';
import { AppUser } from '../types/xstk';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AppUser | null;
  onLoginSuccess: (user: AppUser) => void;
  onOpenDevDatabase?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLoginSuccess,
  onOpenDevDatabase,
}) => {
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [university, setUniversity] = useState('ĐH Bách Khoa TP.HCM');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleQuickDemo = async (role: 'sinh_vien' | 'giang_vien' | 'nha_phat_trien') => {
    setIsLoading(true);
    setErrorMsg('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ demoUserRole: role }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        onLoginSuccess(data.user);
        onClose();
      } else {
        setErrorMsg(data.error || 'Đăng nhập không thành công');
      }
    } catch (err) {
      setErrorMsg('Không thể kết nối máy chủ máy tính EDT');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setErrorMsg('Vui lòng nhập địa chỉ email!');
      return;
    }
    setIsLoading(true);
    setErrorMsg('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          password,
          fullName: tab === 'register' ? fullName : undefined,
          university: tab === 'register' ? university : undefined,
        }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        onLoginSuccess(data.user);
        onClose();
      } else {
        setErrorMsg(data.error || 'Có lỗi xảy ra khi xác thực');
      }
    } catch (err) {
      setErrorMsg('Lỗi kết nối mạng, vui lòng thử lại');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border-2 border-cyan-500/50 rounded-3xl max-w-md w-full p-6 shadow-[0_0_40px_rgba(6,182,212,0.3)] relative overflow-hidden text-slate-100">
        {/* Glow corner accent */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center space-y-1.5 mb-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-cyan-950/70 border border-cyan-500/40 rounded-full text-[11px] font-black text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.2)]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>HỆ THỐNG TÀI KHOẢN EDT CLOUD</span>
          </div>
          <h2 className="text-xl font-black text-white tracking-tight">
            {tab === 'login' ? 'Đăng Nhập Tài Khoản EDT' : 'Đăng Ký Tài Khoản Học Tập'}
          </h2>
          <p className="text-xs text-slate-300 font-medium">
            Lưu trữ tiến độ học, lịch sử bấm máy Casio và đồng bộ kho dữ liệu người dùng.
          </p>
        </div>

        {/* Quick Demo Login Picker */}
        <div className="space-y-2 mb-5 p-3 bg-slate-950/80 rounded-2xl border border-cyan-500/30">
          <div className="flex items-center justify-between text-[11px] font-bold text-cyan-300">
            <span>⚡ Đăng nhập nhanh (1-Click Demo):</span>
            <span className="text-[10px] text-slate-400">Không cần mật khẩu</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => handleQuickDemo('sinh_vien')}
              disabled={isLoading}
              className="p-2.5 bg-slate-800 hover:bg-cyan-950/60 border border-slate-700 hover:border-cyan-400 rounded-xl text-center group transition-all"
            >
              <div className="text-base mb-1">🎓</div>
              <div className="text-[11px] font-bold text-white group-hover:text-cyan-300">Sinh Viên</div>
              <div className="text-[9px] text-slate-400 font-medium">Nguyễn Văn An</div>
            </button>

            <button
              type="button"
              onClick={() => handleQuickDemo('giang_vien')}
              disabled={isLoading}
              className="p-2.5 bg-slate-800 hover:bg-emerald-950/60 border border-slate-700 hover:border-emerald-400 rounded-xl text-center group transition-all"
            >
              <div className="text-base mb-1">👨‍🏫</div>
              <div className="text-[11px] font-bold text-white group-hover:text-emerald-300">Giảng Viên</div>
              <div className="text-[9px] text-slate-400 font-medium">TS. Minh Đức</div>
            </button>

            <button
              type="button"
              onClick={() => handleQuickDemo('nha_phat_trien')}
              disabled={isLoading}
              className="p-2.5 bg-slate-800 hover:bg-purple-950/60 border border-slate-700 hover:border-purple-400 rounded-xl text-center group transition-all"
            >
              <div className="text-base mb-1">💻</div>
              <div className="text-[11px] font-bold text-purple-300 group-hover:text-purple-200">Developer</div>
              <div className="text-[9px] text-slate-400 font-medium">Kho Dữ Liệu</div>
            </button>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800 mb-4 text-xs font-bold">
          <button
            type="button"
            onClick={() => setTab('login')}
            className={`flex-1 py-2 rounded-lg transition-all ${
              tab === 'login'
                ? 'bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 font-black shadow-[0_0_12px_rgba(6,182,212,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Đăng Nhập
          </button>
          <button
            type="button"
            onClick={() => setTab('register')}
            className={`flex-1 py-2 rounded-lg transition-all ${
              tab === 'register'
                ? 'bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 font-black shadow-[0_0_12px_rgba(6,182,212,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Tạo Tài Khoản Mới
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {tab === 'register' && (
            <div>
              <label className="text-[11px] font-bold text-cyan-300 block mb-1">Họ và tên của bạn:</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Ví dụ: Lê Hoàng Long"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs font-medium focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 outline-none"
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-[11px] font-bold text-cyan-300 block mb-1">Địa chỉ Email:</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@student.edu.vn"
                className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs font-medium focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] font-bold text-cyan-300 block mb-1">Mật khẩu:</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs font-medium focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 outline-none"
              />
            </div>
          </div>

          {tab === 'register' && (
            <div>
              <label className="text-[11px] font-bold text-cyan-300 block mb-1">Trường đại học:</label>
              <div className="relative">
                <GraduationCap className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={university}
                  onChange={(e) => setUniversity(e.target.value)}
                  placeholder="Đại học Quốc Gia / Bách Khoa / Kinh Tế"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs font-medium focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 outline-none"
                />
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="p-2.5 bg-rose-950/60 border border-rose-500/50 rounded-xl text-rose-300 text-xs font-semibold">
              {errorMsg}
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-gradient-to-r from-cyan-400 via-teal-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all"
          >
            <span>{isLoading ? 'Đang xác thực...' : tab === 'login' ? 'XÁC NHẬN ĐĂNG NHẬP' : 'TẠO TÀI KHOẢN MỚI'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Developer shortcut if developer logged in */}
        {currentUser?.role === 'nha_phat_trien' && onOpenDevDatabase && (
          <div className="mt-4 pt-3 border-t border-slate-800 text-center">
            <button
              onClick={() => {
                onClose();
                onOpenDevDatabase();
              }}
              className="text-xs font-extrabold text-purple-400 hover:text-purple-300 flex items-center justify-center gap-1.5 mx-auto"
            >
              <Database className="w-4 h-4" />
              <span>Mở Kho Dữ Liệu Nhà Phát Triển (Developer Vault)</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
