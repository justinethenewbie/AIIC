// Complete systematic compilation of all prompts and technical blueprints
// for building the EDT - AI Tutor & Casio Calculator Probability & Statistics Application

export interface PromptStepItem {
  stepNumber: number;
  phaseTitle: string;
  category: string;
  goal: string;
  fullPromptText: string;
  systemInstructionsPrompt?: string;
  technicalImplementation: string[];
  keyOutputs: string[];
}

export const PROMPTS_HISTORY_DATA: PromptStepItem[] = [
  {
    stepNumber: 1,
    phaseTitle: 'Khởi Tạo Kiến Trúc Nền Tảng Ứng Dụng Học Tập XSTK Toàn Diện',
    category: 'Architecture & Core Learning Engine',
    goal: 'Xây dựng toàn bộ nền tảng học tập Xác Suất Thống Kê Đại Học với 7 chương chuẩn, phương pháp Feynman 5 bước, chấm điểm bằng hình ảnh/iPad và phòng vấn đáp AI.',
    fullPromptText: `Hãy xây dựng một ứng dụng web học tập toàn diện cho môn Xác Suất Thống Kê Đại Học (XSTK) theo phong cách hiện đại:
1. Hệ thống bài giảng 7 chương chuẩn đại học theo phương pháp Feynman 5 bước: Đặt vấn đề thực tế -> Bản chất khái niệm -> Công thức KaTeX -> Ví dụ mẫu giáo viên -> Thử sức tại lớp.
2. Công cụ chấm bài tự luận bằng hình ảnh / viết tay trên bảng tương tác iPad với AI Tutor Cú Thông Thái, phản hồi theo barem điểm 10.
3. Phòng thi Vấn đáp AI hai chiều: Giám khảo AI đặt câu hỏi khảo sát sinh viên, hoặc sinh viên tự do gửi câu hỏi, hình ảnh, tài liệu để được giải đáp cặn kẽ.
4. Tương tác giọng nói Speech-to-Text & Text-to-Speech tự động trình chiếu công thức lên bảng iPad.
5. Bản đồ tư duy (Mindmap) 7 chương có thể tùy chỉnh thêm ghi chú và xuất file ảnh.
6. Nhật ký theo dõi lỗi sai thông minh (Mistake Analytics) phân tích nguyên nhân gốc rễ.
7. Diễn đàn học tập cộng đồng có kiểm duyệt nội dung tự động bằng AI.
8. Hệ thống Gamification: Linh vật Cú, chuỗi học tập Streak, EXP, Level, và Rương kho báu mở khóa vật phẩm.`,
    systemInstructionsPrompt: `Bạn là AI Tutor kiêm Chuyên gia Sư phạm Xác suất thống kê Đại học. Khi hướng dẫn sinh viên, luôn ưu tiên giải thích bản chất trực quan theo phương pháp Feynman trước khi đưa ra công thức toán học. Mọi công thức phải được render bằng KaTeX chuẩn mực. Khi chấm bài, cung cấp chiến lược định hướng trước khi đưa ra lời giải hoàn chỉnh.`,
    technicalImplementation: [
      'Thiết lập React SPA với Vite, TypeScript và Tailwind CSS.',
      'Tích hợp KaTeX để hiển thị công thức toán học sắc nét.',
      'Xây dựng Canvas HTML5 tương tác hỗ trợ bút vẽ cảm ứng Stylus / chuột như màn hình iPad.',
      'Tích hợp Web Speech API cho nhận dạng giọng nói và phát âm thanh phản hồi.',
      'Xây dựng backend Express với các endpoint AI Tutor hỗ trợ Gemini Flash API.'
    ],
    keyOutputs: [
      'Bộ dữ liệu 7 chương giáo trình chuẩn (curriculumData.ts).',
      'Thành phần bài giảng 5 bước Feynman tương tác (ChapterLearning.tsx).',
      'Bảng vẽ Canvas chấm bài (InteractiveCanvas.tsx).',
      'Phòng vấn đáp AI hai chiều (TheoreticalViva.tsx).'
    ]
  },
  {
    stepNumber: 2,
    phaseTitle: 'Vi Xử Lý Toán Học 4 Bước & Giải Tích Phân Biến Ngẫu Nhiên Liên Tục',
    category: 'Math Processor & Continuous Variable Analysis',
    goal: 'Biến ứng dụng thành một bộ vi xử lý toán học thông minh, tự động giải các bài toán tích phân biến ngẫu nhiên liên tục theo 4 bước chuẩn và hướng dẫn bấm máy Casio fx-580VN X thực tế.',
    fullPromptText: `Bạn là bộ vi xử lý toán học kiêm gia sư môn Xác suất thống kê đại học.
Vì người dùng nhập liệu trên bàn phím máy tính thông thường hoặc qua bàn phím ảo, họ sẽ gửi biểu thức dưới dạng chữ viết thường hoặc mã LaTeX cơ bản. Nhiệm vụ của bạn là:

1. QUY TẮC ĐỌC KÝ HIỆU CỦA NGƯỜI DÙNG:
- Khi thấy "int(a, b, f(x))" hoặc "\\int_{a}^{b} f(x) dx": Hiểu là tích phân xác định của hàm f(x) từ cận dưới a đến cận trên b.
- Khi thấy "-inf" và "+inf" hoặc "\\infty": Hiểu là âm vô cực và dương vô cực.
- Khi thấy "sum(a, b, f(x))" hoặc "\\sum": Hiểu là tổng xích-ma.
- Khi thấy "sqrt(x)": Hiểu là căn bậc hai của x.
- Khi thấy "e^(x)": Hiểu là số e mũ x.
- Khi thấy "nCr(n, k)" và "nPr(n, k)": Hiểu là tổ hợp chọn k của n và chỉnh hợp.
- Khi thấy "Phi(z)" hoặc "P(Z <= z)": Hiểu là hàm phân phối tích lũy chuẩn tắc.

2. CÁCH GIẢI BÀI TOÁN BIẾN NGẪU NHIÊN LIÊN TỤC (CÓ TÍCH PHÂN):
Khi gặp bài toán tìm hằng số k, hàm mật độ f(x), hàm phân phối F(x), kỳ vọng E(X) = int(-inf, +inf, x*f(x)), hoặc phương sai Var(X) = E(X^2) - [E(X)]^2:
- Bước 1: Viết lại đề bài bằng công thức toán học rõ ràng.
- Bước 2: Tìm nguyên hàm F(x) chi tiết từng bước.
- Bước 3: Thế cận trên trừ cận dưới F(b) - F(a). Nếu cận là vô cực (+inf hoặc -inf), trình bày rõ giới hạn lim.
- Bước 4: Xuất kết quả cuối cùng ở 2 dạng: Phân số tối giản VÀ Số thập phân làm tròn 4 chữ số (giống màn hình Casio fx-580VN X).

3. HƯỚNG DẪN BẤM MÁY CASIO THỰC TẾ:
Cuối mỗi bài giải, luôn kèm theo mục "Cách bấm máy Casio fx-580VN X trong phòng thi":
- Chỉ rõ phím cần bấm (ví dụ: bấm phím Tích phân dưới nút ALPHA, nhập hàm với biến X, nhập cận).
- Nếu cận là dương vô cực (+inf), dặn sinh viên thay bằng số 10^9 (hoặc số 10 đối với phân phối chuẩn tắc) và âm vô cực (-inf) thay bằng -10^9 để máy Casio tính được xấp xỉ chính xác.`,
    systemInstructionsPrompt: `Luôn tuân thủ quy trình 4 bước chuẩn mực và kèm mẹo bấm máy Casio fx-580VN X với mẹo thế 10^9 cho vô cực để sinh viên áp dụng ngay trong phòng thi đại học.`,
    technicalImplementation: [
      'Xây dựng thành phần MathProcessor.tsx chuyên giải toán tích phân và biến liên tục.',
      'Bộ parser nhận diện linh hoạt cả ký hiệu dạng chữ (int, -inf, +inf) lẫn mã KaTeX (\\int, \\infty).',
      'Tích hợp thuật toán tính tích phân số học Simpson và phân tích nguyên hàm symbolic.',
      'Tự động định dạng kết quả kép: Phân số tối giản (fraction) song song với số thập phân 4 chữ số.'
    ],
    keyOutputs: [
      'Module Vi Xử Lý Tích Phân & 4 Bước (MathProcessor.tsx).',
      'Khung hướng dẫn bấm máy Casio fx-580VN X thực tế trong phòng thi.'
    ]
  },
  {
    stepNumber: 3,
    phaseTitle: 'Máy Tính Casio Ảo Chạy Trực Tiếp Trên Web & Bàn Phím Ký Hiệu Đặc Biệt',
    category: 'Virtual Casio Calculator & Keypad UI',
    goal: 'Nâng cấp máy tính xác suất thống kê hoạt động như một chiếc máy tính cầm tay Casio fx-580VN X thực thụ, có bàn phím ảo đầy đủ các ký hiệu giải tích, tổ hợp, phân phối.',
    fullPromptText: `Hãy cập nhật và nâng cấp riêng cho tính năng "Máy tính Xác suất thống kê" ở trong ứng dụng hiện tại của tôi (giữ nguyên các tính năng khác của ứng dụng). Tôi cần tính năng máy tính này hoạt động giống như một chiếc máy tính cầm tay Casio thực thụ trên nền web, giải quyết triệt để bài toán nhập liệu và tính toán cho cả biến ngẫu nhiên rời rạc lẫn biến ngẫu nhiên liên tục. Cụ thể, hãy bổ sung vào tính năng này các điều chỉnh sau:

1. Bổ sung bảng nút bấm ký hiệu đặc biệt (Bàn phím ảo trên màn hình):
Thiết kế thêm các nút bấm trực quan ngay trong công cụ này để người dùng chỉ cần click chuột là chèn được ký hiệu vào ô nhập liệu mà không cần gõ từ bàn phím máy tính:
- Nhóm nút Giải tích cho biến liên tục: Nút Tích phân xác định (có ô nhập cận dưới, cận trên và hàm số bên trong), nút Tích phân suy rộng (từ âm vô cực đến dương vô cực), nút ký hiệu Dương vô cực, nút Âm vô cực, nút Phân số, nút Số mũ, nút Căn bậc hai, và nút hằng số e mũ x.
- Nhóm nút Tổ hợp và Rời rạc: Nút Tổ hợp (nCr), nút Chỉnh hợp (nPr), nút Giai thừa (!), nút Tổng xích-ma.
- Nhóm nút Phân phối và Thống kê: Nút hàm phân phối chuẩn tắc Phi(z), nút tra ngược giá trị tới hạn z-alpha và t-alpha, nút tính Trung bình mẫu, Phương sai mẫu và Độ lệch chuẩn mẫu.

2. Nâng cấp khả năng xử lý các bài toán Biến ngẫu nhiên liên tục (Có chứa tích phân):
Hiện tại tính năng này mới chỉ làm được các bài xác suất thống kê thuần túy, chưa giải được các bài có hàm tích phân. Hãy nâng cấp logic xử lý bên trong tính năng này để khi người dùng bấm phép tính có chứa tích phân, nó phải thực hiện được đầy đủ các việc sau:
- Tính toán chính xác giá trị của tích phân xác định và tích phân suy rộng (khi cận là âm vô cực hoặc dương vô cực).
- Giải quyết trọn vẹn các bài toán về hàm mật độ xác suất f(x) và hàm phân phối tích lũy F(x): tự động kiểm tra điều kiện hàm mật độ, tìm hằng số k chưa biết trong hàm tích phân, tính xác suất trong một khoảng P(a < X < b) bằng tích phân, tính Kỳ vọng E(X) và Phương sai Var(X) của biến ngẫu nhiên liên tục.
- Khi trả về kết quả trên màn hình máy tính, phải hiển thị song song cả kết quả dạng phân số tối giản và dạng số thập phân làm tròn 4 chữ số, kèm theo các bước lấy nguyên hàm và thế cận rõ ràng.`,
    systemInstructionsPrompt: `Không bao giờ từ chối bài toán có chứa tích phân hoặc đạo hàm. Luôn hiển thị song song kết quả phân số và số thập phân 4 chữ số kèm nút chuyển đổi S<=>D như máy tính Casio thật.`,
    technicalImplementation: [
      'Thiết kế giao diện thân máy Casio fx-580VN X với màn hình LCD retro 2 dòng (biểu thức và kết quả).',
      'Chia bàn phím ảo thành 3 nhóm chức năng: Giải tích biến liên tục, Tổ hợp rời rạc, Phân phối thống kê.',
      'Cung cấp phím bấm S<=>D chuyển đổi qua lại giữa phân số tối giản và số thập phân 4 chữ số.',
      'Bổ sung Tab chuyên biệt: "2. BIẾN LIÊN TỤC & TÍCH PHÂN" giải quyết tự động việc tìm hằng số k, kiểm tra hàm mật độ, tính P(a<X<b), E(X), Var(X).'
    ],
    keyOutputs: [
      'Máy tính Casio hoàn chỉnh trong ứng dụng (CasioCalculator.tsx).',
      'Trình giả lập Casio độc lập qua MathLive và Nerdamer JS (public/casio_simulator.html).'
    ]
  },
  {
    stepNumber: 4,
    phaseTitle: 'Trích Xuất Đề Thi & Bài Tập Ra File Word (.doc) và PDF (In A4)',
    category: 'Export & Document Generation',
    goal: 'Bổ sung các nút bấm cho phép sinh viên và giảng viên trích xuất toàn bộ bộ câu hỏi trắc nghiệm và tự luận do AI sinh ra thành file Word và PDF chuyên nghiệp.',
    fullPromptText: `Các tính năng tạo bài tập cần được tạo thêm các nút để trích bài tập ra các định dạng file khác như pdf word.
- Nút Xuất Word (.doc): Tải về file tài liệu mở được trên Microsoft Word, Google Docs với đầy đủ công thức toán học KaTeX, đáp án và lời giải 4 bước.
- Nút Xuất PDF: Xuất trang in khổ A4 chuẩn mực, ngắt trang thông minh, tiêu đề trường/khoa và trường điền thông tin sinh viên phục vụ in đề thi trực tiếp.`,
    systemInstructionsPrompt: `Khi xuất tài liệu Word và PDF, phải định dạng bảng chuẩn hóa, bảo toàn ký tự tiếng Việt Unicode và cung cấp tùy chọn bật/tắt đáp án và lời giải chi tiết.`,
    technicalImplementation: [
      'Xây dựng thư viện exportUtils.ts với hàm exportExercisesToWord và exportExercisesToPdf.',
      'Tạo file MIME type application/msword với mã hóa UTF-8 BOM để hiển thị chuẩn tiếng Việt trong Word.',
      'Tạo cửa sổ in Print-Ready chuẩn khổ giấy A4 (@page size: A4) với CSS tối ưu khi in ra PDF.',
      'Thêm thanh công cụ xuất file trên cả hai trang Trắc nghiệm (McqPractice.tsx) và Tự luận (EssayPractice.tsx).'
    ],
    keyOutputs: [
      'Module xuất file đa năng (exportUtils.ts).',
      'Thanh công cụ xuất đề thi Word & PDF trên giao diện McqPractice và EssayPractice.'
    ]
  },
  {
    stepNumber: 5,
    phaseTitle: 'Đổi Tên Thành EDT & Đồng Bộ Giao Diện Cyber Neon Độ Tương Phản Cao',
    category: 'UI/UX & Modern Neon Harmonization',
    goal: 'Đổi tên toàn bộ thương hiệu ứng dụng thành EDT, loại bỏ các màu cam/amber chói gắt, thiết lập bảng màu Cyber Neon Cyan và Emerald hiện đại với độ tương phản văn bản cao, sắc nét.',
    fullPromptText: `Giao diện đổi thành màu neon hiện đại hài hòa và ngôn ngữ chính là tiếng việt cho cả các tính năng của casio và cũng như đổi tên app thành EDT.
Màu sắc vẫn chưa đồng đều và cần đồng nhất về màu neon hiện đại, màu sắc vẫn còn cam quá và màu sắc các chữ phải nổi bật và nhìn rõ màu nền vì tôi thấy có những màu chữ khá tối không rõ so với màu nền. Cải thiện các tính năng app.`,
    systemInstructionsPrompt: `Đổi tên thương hiệu đồng bộ thành EDT. Sử dụng tone màu chủ đạo là Cyber Neon Cyan (#06b6d4) và Neon Emerald (#10b981) trên nền obsidian slate-950. Tiêu đề phải là chữ trắng tinh với text-shadow neon, nhãn sáng màu, nội dung dùng text-slate-100/200, tuyệt đối không dùng chữ tối màu trên nền tối.`,
    technicalImplementation: [
      'Cập nhật metadata.json, index.html title và OpenGraph tags sang thương hiệu EDT.',
      'Loại bỏ triệt để các class màu amber/orange và các class nền trắng/xám cũ trong toàn bộ components.',
      'Định nghĩa các lớp utility neon trong index.css (.neon-glow-cyan, .neon-glow-emerald, .neon-border-cyan).',
      'Nâng cấp độ tương phản văn bản: Headings text-white drop-shadow neon, Subheadings text-cyan-300, Body text-slate-100 / text-slate-200.'
    ],
    keyOutputs: [
      'Thương hiệu EDT đồng bộ toàn diện trên TopNavbar, Sidebar và Footer.',
      'Giao diện Cyber Neon hiện đại, thống nhất, dễ đọc, không mỏi mắt.'
    ]
  },
  {
    stepNumber: 6,
    phaseTitle: 'Hệ Thống Đăng Nhập & Kho Dữ Liệu Người Dùng Dành Riêng Cho Nhà Phát Triển',
    category: 'User Authentication & Developer Database Vault',
    goal: 'Tạo nút đăng nhập để lưu trữ thông tin người dùng và xây dựng một kho dữ liệu CSDL người dùng dành riêng cho Nhà phát triển với đầy đủ công cụ quản trị, tìm kiếm, chỉnh sửa và xuất file.',
    fullPromptText: `Bạn tạo thêm cả nút đăng nhập để lưu trữ thông tin người dùng nhé, có cả kho dữ liệu người dùng cho riêng nhà phát triển nữa.
- Nút đăng nhập trên thanh điều hướng, modal đăng nhập/đăng ký với tính năng 1-Click Demo đổi vai trò nhanh (Sinh viên, Giảng viên, Nhà phát triển).
- Lưu trữ phiên đăng nhập và dữ liệu tiến độ người dùng.
- Kho dữ liệu người dùng cho riêng nhà phát triển (Dev Database Vault): Thống kê CSDL thời gian thực, bảng người dùng chi tiết, tìm kiếm, lọc theo vai trò, thêm/xóa user, cập nhật quyền và xuất toàn bộ CSDL ra JSON / CSV.`,
    systemInstructionsPrompt: `Xây dựng giải pháp quản trị CSDL người dùng đầy đủ chức năng với API backend RESTful, bảng dữ liệu trực quan cho developer và hỗ trợ xuất file sao lưu CSDL một chạm.`,
    technicalImplementation: [
      'Xây dựng AuthModal.tsx hỗ trợ đăng nhập, đăng ký và chọn vai trò demo tức thì.',
      'Xây dựng DeveloperDatabaseModal.tsx với Dashboard chỉ số CSDL và bảng quản trị người dùng.',
      'Bổ sung các REST API trong server.ts: GET /api/dev/users, POST /api/dev/users, DELETE /api/dev/users/:id, POST /api/auth/login, POST /api/auth/save-progress.',
      'Tích hợp tính năng sao lưu: Xuất CSDL ra JSON backup và xuất ra file CSV bảng tính có hỗ trợ dấu tiếng Việt UTF-8.'
    ],
    keyOutputs: [
      'Thành phần AuthModal.tsx & DeveloperDatabaseModal.tsx.',
      'Các API quản trị người dùng trong server.ts.',
      'Nút "Đăng nhập" và "💾 Kho Dữ Liệu Dev" trên TopNavbar.'
    ]
  }
];
