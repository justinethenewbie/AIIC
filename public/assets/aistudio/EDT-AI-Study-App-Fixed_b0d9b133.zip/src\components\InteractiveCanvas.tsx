import React, { useRef, useState, useEffect } from 'react';
import { Pencil, Eraser, Trash2, Bold, Italic, Underline, Sigma, Upload, Check, Type } from 'lucide-react';

interface InteractiveCanvasProps {
  onExportCanvas: (dataUrl: string, textContent: string) => void;
  isSubmitting?: boolean;
  initialText?: string;
}

export const InteractiveCanvas: React.FC<InteractiveCanvasProps> = ({
  onExportCanvas,
  isSubmitting = false,
  initialText = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [color, setColor] = useState('#1e293b');
  const [lineWidth, setLineWidth] = useState(3);
  const [mode, setMode] = useState<'draw' | 'erase' | 'text'>('draw');
  const [typedText, setTypedText] = useState(initialText);

  // Formatting states for text
  const [isBold, setIsBold] = useState(false);
  const [isItalic, setIsItalic] = useState(false);
  const [isUnderline, setIsUnderline] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Fill white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (mode === 'text') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    ctx.beginPath();
    ctx.moveTo(clientX - rect.left, clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing || mode === 'text') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    ctx.lineWidth = mode === 'erase' ? 24 : lineWidth;
    ctx.lineCap = 'round';
    ctx.strokeStyle = mode === 'erase' ? '#ffffff' : color;

    ctx.lineTo(clientX - rect.left, clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  const insertSymbol = (sym: string) => {
    setTypedText((prev) => prev + sym);
  };

  const handleExport = () => {
    const canvas = canvasRef.current;
    const dataUrl = canvas ? canvas.toDataURL('image/png') : '';
    onExportCanvas(dataUrl, typedText);
  };

  const MATH_SYMBOLS = [
    'Ω',
    'P(A)',
    'P(A|B)',
    'P(A+B)',
    'C_n^k',
    'μ',
    'σ²',
    'x̄',
    's²',
    'Φ(z)',
    'χ²',
    'Z_qs',
    'T_qs',
    'F_qs',
    'H₀',
    'H₁',
    'α',
    '√n',
    '∫',
    '±',
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
      {/* Top Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
          <button
            onClick={() => setMode('draw')}
            className={`p-1.5 rounded-md flex items-center gap-1 font-medium transition-colors ${
              mode === 'draw' ? 'bg-white dark:bg-slate-700 text-amber-600 dark:text-amber-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
            }`}
            title="Vẽ tay iPad / Chuột"
          >
            <Pencil className="w-3.5 h-3.5" />
            <span>Viết iPad</span>
          </button>

          <button
            onClick={() => setMode('erase')}
            className={`p-1.5 rounded-md flex items-center gap-1 font-medium transition-colors ${
              mode === 'erase' ? 'bg-white dark:bg-slate-700 text-amber-600 dark:text-amber-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
            }`}
            title="Tẩy nét vẽ"
          >
            <Eraser className="w-3.5 h-3.5" />
            <span>Tẩy</span>
          </button>

          <button
            onClick={() => setMode('text')}
            className={`p-1.5 rounded-md flex items-center gap-1 font-medium transition-colors ${
              mode === 'text' ? 'bg-white dark:bg-slate-700 text-amber-600 dark:text-amber-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
            }`}
            title="Soạn thảo văn bản Word"
          >
            <Type className="w-3.5 h-3.5" />
            <span>Gõ phím Word</span>
          </button>
        </div>

        {/* Word Formatting Controls */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
          <button
            onClick={() => setIsBold(!isBold)}
            className={`p-1.5 rounded ${isBold ? 'bg-amber-200 text-amber-900 font-bold' : 'text-slate-600 dark:text-slate-300'}`}
          >
            <Bold className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsItalic(!isItalic)}
            className={`p-1.5 rounded ${isItalic ? 'bg-amber-200 text-amber-900' : 'text-slate-600 dark:text-slate-300'}`}
          >
            <Italic className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsUnderline(!isUnderline)}
            className={`p-1.5 rounded ${isUnderline ? 'bg-amber-200 text-amber-900' : 'text-slate-600 dark:text-slate-300'}`}
          >
            <Underline className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Color Palette */}
        {mode === 'draw' && (
          <div className="flex items-center gap-1.5">
            {['#1e293b', '#2563eb', '#dc2626', '#16a34a'].map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className={`w-5 h-5 rounded-full border-2 transition-transform ${color === c ? 'scale-125 border-amber-500' : 'border-transparent'}`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        )}

        <button
          onClick={clearCanvas}
          className="p-1.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg flex items-center gap-1 transition-colors"
          title="Xóa trắng bảng"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Xóa bảng</span>
        </button>
      </div>

      {/* Special Math Symbols Bar */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 text-xs no-scrollbar">
        <span className="text-[10px] font-bold text-slate-400 shrink-0 flex items-center gap-0.5">
          <Sigma className="w-3 h-3" /> Ký tự XSTK:
        </span>
        {MATH_SYMBOLS.map((sym) => (
          <button
            key={sym}
            onClick={() => insertSymbol(sym)}
            className="px-2 py-1 bg-slate-100 hover:bg-amber-100 dark:bg-slate-800 dark:hover:bg-amber-950/60 text-slate-700 dark:text-slate-200 rounded font-mono font-medium shrink-0 transition-colors"
          >
            {sym}
          </button>
        ))}
      </div>

      {/* Drawing Pad + Text Area Split */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Drawing Pad Canvas */}
        <div className="relative border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden bg-white shadow-inner min-h-[180px]">
          <div className="absolute top-2 left-2 text-[10px] bg-slate-100/80 px-2 py-0.5 rounded text-slate-500 font-mono pointer-events-none z-10">
            Bảng iPad Viết tay / Chuột
          </div>
          <canvas
            ref={canvasRef}
            width={400}
            height={200}
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
            className="w-full h-full cursor-crosshair touch-none"
          />
        </div>

        {/* Typed Math Input Box */}
        <div className="flex flex-col">
          <label className="text-[10px] font-semibold text-slate-500 mb-1">
            Soạn thảo lời giải / Công thức gõ phím Word:
          </label>
          <textarea
            value={typedText}
            onChange={(e) => setTypedText(e.target.value)}
            placeholder="Nhập bước giải bài toán XSTK của bạn tại đây..."
            className={`w-full flex-1 p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500 text-xs leading-relaxed resize-none ${
              isBold ? 'font-bold' : ''
            } ${isItalic ? 'italic' : ''} ${isUnderline ? 'underline' : ''}`}
          />
        </div>
      </div>

      {/* Submit Action Button */}
      <div className="flex justify-end pt-1">
        <button
          onClick={handleExport}
          disabled={isSubmitting}
          className="py-2.5 px-5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-medium rounded-xl shadow transition-all flex items-center gap-2 text-xs"
        >
          {isSubmitting ? (
            <>
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              <span>AI Tutor đang phân tích & chấm điểm...</span>
            </>
          ) : (
            <>
              <Check className="w-4 h-4" />
              <span>Nộp Bài Làm Để AI Tutor Chấm Điểm</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
