# Kế Hoạch Sửa Lỗi Ký Hiệu Công Thức Math KaTeX & Nâng Cấp Tiến Trình Giảng Dạy Real Teacher

## User Review Required
> [!IMPORTANT]
> - **Sửa triệt để lỗi ký hiệu/mã LaTeX**: Tích hợp thư viện KaTeX để hiển thị toàn bộ công thức toán học (phân số, căn thức, tích phân, $\Omega$, $\mu$, $\sigma$, $\Phi(z)$, $\chi^2$, $t_{\alpha/2}$, $F$) một cách chuẩn xác, đẹp mắt như sách giáo khoa.
> - **Chuyển đổi giao diện**: Bỏ chia màn hình 3 cửa sổ song song; chuyển sang hiển thị **chính xác 1 trang duy nhất** tại một thời điểm, có thanh điều hướng chuyển trang mượt mà ở phía dưới.
> - **Quy trình giảng dạy chuẩn giáo viên**: Cấu trúc lại phần lý thuyết theo 5 bước sư phạm tương tác thực tế (Đặt vấn đề -> Giảng giải bản chất -> Công thức toán -> Ví dụ giáo viên -> Tương tác củng cố).

---

## Proposed Changes

### 1. Sửa Lỗi Ký Hiệu Công Thức Toán (Math Formula Rendering)
- Tích hợp `katex` và `@types/katex` vào dự án.
- Tạo component `MathFormula.tsx` dùng KaTeX để render chuẩn các biểu thức LaTeX như:
  - Phân phối Chuẩn: $f(x) = \frac{1}{\sigma \sqrt{2\pi}} e^{-\frac{(x-\mu)^2}{2\sigma^2}}$
  - Xác suất có điều kiện: $P(A|B) = \frac{P(AB)}{P(B)}$
  - Công thức Bayes: $P(H_i|A) = \frac{P(H_i) \cdot P(A|H_i)}{\sum P(H_j) \cdot P(A|H_j)}$
  - Tiêu chuẩn kiểm định: $Z_{qs} = \frac{\bar{x} - \mu_0}{s/\sqrt{n}}$, $T_{qs}$, $\chi^2_{qs}$, $F_{qs}$.
- Áp dụng `MathFormula` trên toàn bộ các trang Lý thuyết, Bài tập thực hành, Bài tập về nhà, Máy tính Casio và Vấn đáp AI.

### 2. Cấu Trúc Lại Trình Tự Giảng Dạy Sư Phạm (Real Teacher Pedagogy)
- Cập nhật `ChapterLearning.tsx` hoạt động như một tiết học thực thụ:
  - **Bước 1: Đặt vấn đề thực tế**: Bài toán ngân hàng/tài chính/sản xuất mở đầu thu hút sinh viên.
  - **Bước 2: Giảng giải bản chất (Feynman)**: Giải thích bằng ngôn ngữ sinh viên dễ hiểu nhất.
  - **Bước 3: Xây dựng công thức & Ký hiệu KaTeX**: Trình bày công thức sạch đẹp, có giải thích ý nghĩa từng đại lượng.
  - **Bước 4: Ví dụ mẫu của giáo viên**: Lời giải mẫu từng bước chi tiết.
  - **Bước 5: Câu hỏi kiểm tra củng cố tại lớp**: Sinh viên làm thử trên bảng iPad/gõ phím và AI Tutor nhận xét tức thì.

### 3. Thay Đổi Giao Diện Chuyển Trang Single-Page Nav
- Loại bỏ chế độ hiển thị 3 cửa sổ chia nhỏ cùng lúc.
- Cập nhật `App.tsx` và `BottomPageSwitcher.tsx`:
  - Luôn hiển thị **1 trang đầy đủ (Full Page)** duy nhất.
  - Thanh chuyển trang cố định phía dưới giúp chuyển nhanh giữa các công cụ AI (Lý thuyết, Chấm Bảng iPad, Vấn đáp, Trắc nghiệm, Máy tính Casio, Diễn đàn, Hồ sơ).

---

## Verification Plan

### Automated Verification
1. Chạy `install_applet_package` để cài đặt `katex`.
2. Kiểm tra biên dịch dự án bằng `compile_applet`.

### Manual Verification
1. Kiểm tra công thức $N(\mu, \sigma^2)$ và các ký hiệu toán học ở Bài 1 - Bài 7 xem có hiển thị phân số, căn thức đẹp mắt không bị hiện mã thô `\frac`.
2. Thử nghiệm tiến trình giảng dạy 5 bước ở mục Lý thuyết.
3. Chuyển đổi giữa các trang ở thanh điều hướng phía dưới xem giao diện hiển thị 1 trang duy nhất mượt mà hay không.
