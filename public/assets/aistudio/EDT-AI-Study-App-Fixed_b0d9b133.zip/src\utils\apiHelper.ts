/**
 * Utility helper for AI API calls in EDT Application
 * Automatically retrieves the user's configured Gemini API Key and Model from localStorage
 * and attaches them to HTTP headers.
 */

export const STORAGE_KEY_GEMINI_API_KEY = 'edt_gemini_api_key';
export const STORAGE_KEY_GEMINI_MODEL = 'edt_gemini_model';

export function getSavedApiKey(): string {
  try {
    return localStorage.getItem(STORAGE_KEY_GEMINI_API_KEY) || '';
  } catch {
    return '';
  }
}

export function setSavedApiKey(key: string): void {
  try {
    localStorage.setItem(STORAGE_KEY_GEMINI_API_KEY, key.trim());
  } catch (err) {
    console.error('Failed to save API key:', err);
  }
}

export function getSavedModel(): string {
  try {
    return localStorage.getItem(STORAGE_KEY_GEMINI_MODEL) || 'gemini-2.5-flash';
  } catch {
    return 'gemini-2.5-flash';
  }
}

export function setSavedModel(model: string): void {
  try {
    localStorage.setItem(STORAGE_KEY_GEMINI_MODEL, model.trim());
  } catch (err) {
    console.error('Failed to save Model:', err);
  }
}

/**
 * Enhanced fetch wrapper that attaches x-gemini-api-key and x-gemini-model headers
 */
export async function aiFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const apiKey = getSavedApiKey();
  const model = getSavedModel();

  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  if (apiKey) {
    headers.set('x-gemini-api-key', apiKey);
  }
  if (model) {
    headers.set('x-gemini-model', model);
  }

  return fetch(url, {
    ...options,
    headers,
  });
}
